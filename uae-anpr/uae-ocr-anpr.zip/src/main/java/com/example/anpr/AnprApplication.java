package com.example.anpr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnprApplication {
    public static void main(String[] args) {
        SpringApplication.run(AnprApplication.class, args);
    }
}
