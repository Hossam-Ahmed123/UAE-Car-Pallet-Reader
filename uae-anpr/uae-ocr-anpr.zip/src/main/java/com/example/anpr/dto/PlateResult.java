package com.example.anpr.dto;

public record PlateResult(String number, String letter, String emirate, String rawText) {}
