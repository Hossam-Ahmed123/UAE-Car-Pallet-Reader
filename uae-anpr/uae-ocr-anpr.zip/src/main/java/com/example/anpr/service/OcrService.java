package com.example.anpr.service;

import com.example.anpr.util.ImageUtils;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.bytedeco.opencv.opencv_core.Mat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class OcrService {

    private final Tesseract tess;

    public OcrService(@Value("${ocr.tessdataPath}") String tessdataPath,
                      @Value("${ocr.lang:eng+ara}") String lang,
                      @Value("${ocr.whitelist}") String whitelist) {
        this.tess = new Tesseract();
        this.tess.setDatapath(tessdataPath);
        this.tess.setLanguage(lang);
        this.tess.setTessVariable("user_defined_dpi", "300");
        if (whitelist != null && !whitelist.isBlank()) {
            this.tess.setTessVariable("tessedit_char_whitelist", whitelist);
        }
    }

    public String doOcr(Mat mat) {
        try {
            return tess.doOCR(ImageUtils.toBufferedImage(mat));
        } catch (TesseractException e) {
            throw new RuntimeException("OCR failed", e);
        }
    }
}
