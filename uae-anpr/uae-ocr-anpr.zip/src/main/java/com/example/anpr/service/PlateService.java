package com.example.anpr.service;

import com.example.anpr.dto.PlateResponse;
import com.example.anpr.dto.PlateResult;
import com.example.anpr.util.EmirateParser;
import com.example.anpr.util.ImageUtils;
import org.bytedeco.opencv.opencv_core.Mat;
import org.bytedeco.opencv.opencv_core.Rect;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PlateService {

    private final OcrService ocr;

    public PlateService(OcrService ocr) {
        this.ocr = ocr;
    }

    public PlateResponse recognize(byte[] imageBytes) {
        Mat src = ImageUtils.readMat(imageBytes);

        // Try find ROI that looks like a plate; otherwise use whole image
        Rect roi = ImageUtils.tryFindPlateROI(src);
        Mat plateRegion = (roi != null) ? new Mat(src, roi).clone() : src;

        // Preprocess for OCR
        Mat gray = ImageUtils.toGray(plateRegion);
        Mat bin = ImageUtils.enhanceForOCR(gray);

        String raw = ocr.doOcr(bin);
        EmirateParser.Parsed parsed = EmirateParser.parse(raw);

        PlateResult one = new PlateResult(parsed.number, parsed.letter, parsed.emirate, raw);
        List<PlateResult> results = new ArrayList<>();
        results.add(one);
        return new PlateResponse(results);
    }
}
