package com.example.anpr.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmirateParser {

    public static class Parsed {
        public String number = "";
        public String letter = "";
        public String emirate = "Unknown";
    }

    public static Parsed parse(String raw) {
        String t = raw == null ? "" : raw.replaceAll("[^\\p{IsAlphabetic}\\p{IsDigit}\\s]", " ").toUpperCase();

        String emirate = "Unknown";
        if (t.contains("DUBAI") || t.contains("دبي")) emirate = "Dubai";
        else if (t.contains("ABU DHABI") || t.contains("ابوظبي") || t.contains("أبوظبي")) emirate = "Abu Dhabi";
        else if (t.contains("SHARJAH") || t.contains("الشارقة")) emirate = "Sharjah";
        else if (t.contains("AJMAN") || t.contains("عجمان")) emirate = "Ajman";
        else if (t.contains("RAK") || t.contains("رأس الخيمة") || t.contains("راس الخيمة")) emirate = "Ras Al Khaimah";
        else if (t.contains("FUJAIRAH") || t.contains("الفجيرة")) emirate = "Fujairah";
        else if (t.contains("UMM AL QUWAIN") || t.contains("أم القيوين") || t.contains("ام القيوين")) emirate = "Umm Al Quwain";

        Matcher mNum = Pattern.compile("\\b(\\d{3,6})\\b").matcher(t);
        String number = mNum.find() ? mNum.group(1) : "";

        Matcher mLet = Pattern.compile("\\b([A-Z]{1,2})\\b").matcher(t);
        String letter = mLet.find() ? mLet.group(1) : "";

        Parsed p = new Parsed();
        p.number = number;
        p.letter = letter;
        p.emirate = emirate;
        return p;
    }
}
